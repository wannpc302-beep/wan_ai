CREATE TABLE IF NOT EXISTS usage_limits (
  bucket TEXT NOT NULL,
  day TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (bucket, day)
);
CREATE INDEX IF NOT EXISTS idx_usage_limits_day ON usage_limits(day);
