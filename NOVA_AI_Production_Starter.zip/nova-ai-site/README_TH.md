# NOVA AI — คู่มือติดตั้งฉบับ Android (ภาษาไทย)

โปรเจกต์นี้ประกอบด้วยหน้าเว็บ NOVA AI, Cloudflare Worker ที่เรียก Gemini API โดยเก็บคีย์ไว้ฝั่งเซิร์ฟเวอร์, ระบบสมัคร/เข้าสู่ระบบผ่าน Supabase Auth, ตารางโปรไฟล์สมาชิก และโควตาการใช้งานรายวันผ่าน Cloudflare D1

> **ข้อสำคัญ:** ฉันจัดเตรียมและตรวจ syntax ของไฟล์ในโปรเจกต์ให้แล้ว แต่ยังไม่สามารถเผยแพร่แทนคุณได้ เพราะต้องใช้บัญชี Cloudflare, Supabase และ Gemini API Key ของคุณเอง ขั้นตอนด้านล่างต้องทำให้ครบก่อนระบบออนไลน์จะทำงานจริง

## ฟังก์ชันและขีดจำกัดเริ่มต้น

- หน้าเว็บ Responsive ภาษาไทย พร้อมธีมและสีเดิม
- สมัครสมาชิก/เข้าสู่ระบบด้วยอีเมลและรหัสผ่านผ่าน Supabase Auth
- โปรไฟล์เริ่มต้นเป็น `free`; ผู้ดูแลเปลี่ยนแผนเป็น `plus` หรือ `pro` ได้ใน Supabase SQL Editor
- โควตาต่อวัน: ผู้เยี่ยมชม 3 ข้อความ, free 20, plus 60, pro 100, admin 500 (ใช้ D1 และนับตามวัน UTC)
- Worker เลือกโมเดลแบบ heuristic: คำถามทั่วไปใช้ `GEMINI_MODEL_FAST`; งานโค้ด/วิเคราะห์ยาวใช้ `GEMINI_MODEL_PRO` หากไม่ได้กำหนด จะ fallback ไป `GEMINI_MODEL` หรือ `gemini-2.5-flash`
- ประวัติแชตเก็บใน localStorage ของอุปกรณ์ ไม่ซิงก์ข้ามอุปกรณ์

## สิ่งที่ต้องมี

1. บัญชี Cloudflare: <https://dash.cloudflare.com/>
2. บัญชี Supabase: <https://supabase.com/dashboard>
3. Gemini API Key จาก Google AI Studio: <https://aistudio.google.com/app/apikey>
4. Android ใช้ Chrome และแอปจัดการไฟล์ได้ แต่การแก้ไฟล์/รันคำสั่งสะดวกกว่าผ่าน GitHub Codespaces หรือคอมพิวเตอร์ หากทำจากมือถืออย่างเดียว ให้ใช้ Cloudflare Dashboard + GitHub Web เป็นหลัก

## ขั้นตอน A — ตั้งค่า Supabase (ระบบสมาชิก)

1. เข้า Supabase Dashboard แล้วสร้าง Project ใหม่ ตั้งรหัสผ่านฐานข้อมูลและเก็บไว้ส่วนตัว
2. เปิด **SQL Editor → New query**
3. เปิดไฟล์ `schema.sql` จาก ZIP, คัดลอกเนื้อหาทั้งหมด แล้ววางใน SQL Editor จากนั้นกด **Run**
4. ไปที่ **Project Settings → API** (บางหน้าจออาจอยู่ใน **Project Settings → Data API**) แล้วจดค่า Project URL และ publishable/anon key
5. ไปที่ **Authentication → URL Configuration** ตั้ง Site URL เป็น URL เว็บที่ได้จาก Cloudflare หลังเผยแพร่ เช่น `https://ชื่อโปรเจกต์.workers.dev` (ตั้งทีหลังได้)
6. ถ้าต้องการให้สมัครสมาชิกแล้วต้องยืนยันอีเมล ให้เปิด Email confirmations ไว้; ถ้าเปิด ผู้ใช้ต้องกดลิงก์ในอีเมลก่อนเข้าสู่ระบบ

**ห้ามนำ `service_role` key ไปใส่ใน HTML หรือส่งให้ผู้ใช้** ค่านี้จะใส่เป็น Cloudflare Secret เท่านั้น

## ขั้นตอน B — สร้างฐานข้อมูลจำกัดโควตาใน Cloudflare D1

1. เข้า Cloudflare Dashboard → **Storage & databases → D1 SQL Database** (ชื่อเมนูอาจเปลี่ยนเล็กน้อย)
2. กด **Create database** ตั้งชื่อ `nova-ai-usage`
3. เปิดฐานข้อมูลที่สร้าง แล้วจด **Database ID**
4. เปิดไฟล์ `wrangler.jsonc` ใน GitHub Web Editor หรือ Codespaces
5. แทนที่ `REPLACE_WITH_D1_DATABASE_ID` ด้วย Database ID จริง แล้วบันทึก
6. เปิด D1 → **Console** แล้วคัดลอกเนื้อหา `migrations.sql` วางและกด Execute

ถ้าไม่สร้าง D1 หรือไม่ตั้ง Database ID, Worker จะปฏิเสธคำขอแชตเพื่อป้องกันการใช้ API โดยไม่มีโควตา

## ขั้นตอน C — อัปโหลดโปรเจกต์และเผยแพร่จาก Android

**วิธีที่แนะนำ: GitHub + Cloudflare Workers Builds**

1. ดาวน์โหลด ZIP นี้ลงมือถือแล้วแตกไฟล์ด้วยแอปจัดการไฟล์
2. เข้า <https://github.com/> และสร้าง repository ใหม่ เช่น `nova-ai-site` ตั้งเป็น Private ได้
3. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดจากในโฟลเดอร์ `nova-ai-site` ไปไว้ที่ราก repository ให้เห็น `wrangler.jsonc`, `src/`, `public/`, `schema.sql` และ `migrations.sql` ในระดับแรก
4. เข้า Cloudflare Dashboard → **Workers & Pages** → **Create** → เลือก **Connect to Git** (หรือ Workers Builds) แล้วเชื่อม GitHub repository นี้
5. ตั้งชื่อ Worker เป็น `nova-ai-site` และให้ใช้ `wrangler.jsonc` ที่อยู่ใน repository; ถ้าหน้าตั้งค่าถาม Build command ให้ใช้ `npx wrangler deploy` และไม่ต้องตั้ง Build output directory เพราะ Worker ใช้ Assets จาก `public/`
6. ถ้า Dashboard แจ้งว่า `database_id` ไม่ถูกต้อง ให้ตรวจว่าทำขั้นตอน B ข้อ 4–5 แล้ว
7. กด Deploy แล้วเปิด URL ที่ Cloudflare แสดง เช่น `https://nova-ai-site.<บัญชี>.workers.dev`

ถ้าเมนูเชื่อม Git ไม่ปรากฏในบัญชีของคุณ ให้ใช้ GitHub Codespaces เปิด Terminal ที่ repository แล้วรัน `npm install -D wrangler` และ `npx wrangler deploy` ตามที่ระบบแนะนำ โดยต้องล็อกอิน Cloudflare ก่อน

## ขั้นตอน D — ตั้ง Secrets และตัวแปร Worker

ใน Cloudflare Dashboard → Worker `nova-ai-site` → **Settings → Variables and Secrets** ให้เพิ่ม:

| ชื่อ | ประเภท | ค่า |
|---|---|---|
| `GEMINI_API_KEY` | Secret | API Key จาก Google AI Studio |
| `SUPABASE_URL` | Variable | Project URL ของ Supabase เช่น `https://xxxx.supabase.co` |
| `SUPABASE_ANON_KEY` | Variable | publishable/anon key ของ Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | **Secret** | service_role key จาก Supabase API settings |
| `GEMINI_MODEL_FAST` | Variable (ไม่บังคับ) | `gemini-2.5-flash` |
| `GEMINI_MODEL_PRO` | Variable (ไม่บังคับ) | โมเดลที่บัญชีคุณมีสิทธิ์ใช้ เช่น `gemini-2.5-pro` หากยังใช้ได้ในบัญชี |

บันทึกแล้วกด **Deploy** อีกครั้ง ถ้าเพิ่ม Secret ในหน้า Bindings/Settings ระบบอาจให้กด Save and deploy

## ขั้นตอน E — ทดสอบเว็บ

1. เปิด `https://ชื่อเว็บของคุณ/api/health`
2. ควรเห็น `ok: true`, `aiConfigured: true`, `authConfigured: true`, `membershipConfigured: true`, `rateLimitConfigured: true`
3. เปิดหน้าเว็บ กด **เข้าสู่ระบบ / สมัครสมาชิก** แล้วสร้างบัญชีด้วยอีเมลของตัวเอง
4. หากเปิดยืนยันอีเมล ให้ไปยืนยันจากอีเมลก่อน แล้วเข้าสู่ระบบ
5. ส่งข้อความทดลอง เช่น `สวัสดี ช่วยแนะนำตัวหน่อย`
6. ทดสอบออกจากระบบและเข้าสู่ระบบใหม่

ถ้าขึ้นข้อผิดพลาด ให้เปิด `/api/health` และตรวจชื่อตัวแปรตามตารางก่อน อย่าส่ง API Key หรือ service_role key ให้ใคร

## ขั้นตอน F — จัดการสมาชิกและแผน

เปิด Supabase → SQL Editor แล้วใช้คำสั่งตัวอย่างนี้ เปลี่ยนอีเมลเป็นอีเมลของสมาชิกจริง:

```sql
-- ยกระดับผู้ใช้เป็น Plus
update public.profiles
set plan = 'plus'
where id = (select id from auth.users where email = 'member@example.com');

-- ยกระดับผู้ใช้เป็น Pro
update public.profiles
set plan = 'pro'
where id = (select id from auth.users where email = 'member@example.com');

-- กำหนดผู้ดูแล (ให้เฉพาะบัญชีของคุณเอง)
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'you@example.com');
```

การเปลี่ยน `plan` เป็นเพียงการตั้งสิทธิ์ในฐานข้อมูล ยังไม่มีระบบชำระเงินอัตโนมัติ/ตรวจสลิป/ต่ออายุสมาชิก ต้องเพิ่มระบบชำระเงินแยกต่างหากก่อนขายสมาชิกจริง

## ความปลอดภัยและข้อจำกัดที่ควรรู้

- ไม่ใส่ Gemini API Key หรือ Supabase service_role key ใน `public/index.html`, repository หรือภาพหน้าจอ
- โควตานับตามวัน UTC และนับคำขอก่อนเรียก Gemini; คำขอที่ Gemini ล้มเหลวอาจใช้โควตาไปหนึ่งครั้ง
- ระบบนี้เป็นรุ่นเริ่มต้น ไม่ใช่ระบบรับประกันป้องกันการโจมตีทุกรูปแบบ; ก่อนเปิดสาธารณะวงกว้างควรเพิ่ม Cloudflare Turnstile, แจ้งเตือนค่าใช้จ่าย, จำกัดงบ/โควตาที่ฝั่ง Google และตรวจ logs
- แผนสมาชิกไม่ได้ทำให้โมเดล AI เก่งขึ้นโดยอัตโนมัติ; การเลือกโมเดลขึ้นกับตัวแปร Worker และโมเดลที่บัญชี Gemini API รองรับ
- อย่าใช้ระบบนี้เก็บข้อมูลอ่อนไหวหรือรหัสผ่านของบริการอื่น

## ไฟล์สำคัญ

- `public/index.html` — หน้าเว็บ
- `src/index.js` — API Worker, auth validation, model routing, daily limits
- `wrangler.jsonc` — Worker, static assets และ D1 binding
- `schema.sql` — ตารางโปรไฟล์และ trigger ของ Supabase
- `migrations.sql` — ตารางโควตา Cloudflare D1
